const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const puppeteer = require('puppeteer');
const sgMail = require('@sendgrid/mail');

const app = express();
app.use(cors());
app.use(express.json());

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

mongoose.connect('mongodb://localhost/joblessGPT', { useNewUrlParser: true, useUnifiedTopology: true });

const User = mongoose.model('User', {
  email: String,
  cv: String,
  coverLetter: String,
  preferences: {
    location: String,
    hourlyRate: Number,
    shift: String
  }
});

app.post('/api/user', async (req, res) => {
  const user = await User.create(req.body);
  res.json(user);
});

app.get('/api/jobs', (req, res) => {
  res.json([
    { title: "Bar Staff", rate: "£12/hr", location: "Leicester" },
    { title: "Delivery Driver", rate: "£13/hr", location: "Remote" }
  ]);
});

app.get('/api/scrape', async (req, res) => {
  const query = req.query.q || "part time";
  const location = req.query.l || "Leicester";
  const email = req.query.email || null;

  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    const searchURL = \`https://uk.indeed.com/jobs?q=\${encodeURIComponent(query)}&l=\${encodeURIComponent(location)}\`;

    await page.goto(searchURL, { waitUntil: 'domcontentloaded' });

    const jobs = await page.evaluate(() => {
      const listings = [];
      const items = document.querySelectorAll('.result');

      items.forEach(item => {
        const title = item.querySelector('h2.jobTitle')?.innerText;
        const company = item.querySelector('.companyName')?.innerText;
        const location = item.querySelector('.companyLocation')?.innerText;
        const summary = item.querySelector('.job-snippet')?.innerText;
        const link = item.querySelector('a')?.href;

        if (title && company && location) {
          listings.push({ title, company, location, summary, link });
        }
      });

      return listings.slice(0, 5);
    });

    await browser.close();

    if (email) {
      const jobList = jobs.map(j => \`<b>\${j.title}</b> at \${j.company} - \${j.location}<br>\${j.summary}<br><a href="\${j.link}">Apply</a><br><br>\`).join('');
      const msg = {
        to: email,
        from: 'joblessgpt@app.com',
        subject: '🔥 New Jobs Just for You!',
        html: \`<p>Here are your top job matches:</p>\${jobList}\`,
      };
      await sgMail.send(msg);
    }

    res.json(jobs);
  } catch (err) {
    console.error(err);
    res.status(500).send("Scraping or email failed");
  }
});

app.listen(5000, () => console.log("Server started on port 5000"));