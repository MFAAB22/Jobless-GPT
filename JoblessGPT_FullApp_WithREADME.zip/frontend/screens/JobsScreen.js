import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import axios from 'axios';

export default function JobsScreen() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/scrape?q=bar+staff&l=Leicester')
      .then(res => setJobs(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <View style={styles.container}>
      <FlatList
        data={jobs}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.title}>{item.title}</Text>
            <Text>{item.company} • {item.location}</Text>
            <Text>{item.summary}</Text>
          </View>
        )}
      />
    </View>
  );
}
const styles = StyleSheet.create({
  container: { padding: 20 },
  card: { marginBottom: 15, padding: 10, backgroundColor: '#f0f0f0', borderRadius: 8 },
  title: { fontWeight: 'bold', fontSize: 16 }
});