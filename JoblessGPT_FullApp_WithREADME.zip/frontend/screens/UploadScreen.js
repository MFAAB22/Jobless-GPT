import React from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';
import DocumentPicker from 'react-native-document-picker';

export default function UploadScreen({ navigation, route }) {
  const [cv, setCv] = React.useState(null);
  const [cover, setCover] = React.useState(null);

  const pickFile = async (setter) => {
    try {
      const res = await DocumentPicker.pickSingle();
      setter(res.name);
    } catch (err) {
      console.warn(err);
    }
  };

  return (
    <View style={styles.container}>
      <Button title="Upload CV" onPress={() => pickFile(setCv)} />
      <Text>{cv}</Text>
      <Button title="Upload Cover Letter" onPress={() => pickFile(setCover)} />
      <Text>{cover}</Text>
      <Button title="Next" onPress={() => navigation.navigate('Preferences', { email: route.params.email })} />
    </View>
  );
}
const styles = StyleSheet.create({ container: { padding: 20 } });