# 💼 JoblessGPT

> **An AI-powered job search assistant that scrapes and applies for jobs while you chill.**

---

## 🚀 Features

- 📄 Upload CV & cover letter
- 🧠 Set preferences: pay, location, shift
- 🔍 Auto-scrape jobs from Indeed
- 📬 Email notifications with fresh job leads
- 📱 Cross-platform mobile app (built with React Native)
- ☁️ Ready for deployment on Render (backend) & Expo (frontend)

---

## 🧰 Tech Stack

| Layer        | Tech                       |
|--------------|----------------------------|
| Frontend     | React Native (Expo)        |
| Backend      | Node.js + Express          |
| Scraper      | Puppeteer                  |
| Email        | SendGrid API               |
| Database     | MongoDB (local/Atlas)      |
| Deployment   | Render (backend), Expo Go  |

---

## 🧪 Local Setup

### 🔙 Backend

1. Navigate to `backend/`
2. Install dependencies:
```bash
npm install
```
3. Set environment variable:
```bash
SENDGRID_API_KEY=your_sendgrid_key
```
4. Start the server:
```bash
node server.js
```

### 📲 Frontend

1. Navigate to `frontend/`
2. Install Expo CLI:
```bash
npm install -g expo-cli
```
3. Start the app:
```bash
expo start
```
4. Scan QR with Expo Go on your phone.

---

## 📤 Deploy

### Backend (Render)
- Create new Web Service
- Add `SENDGRID_API_KEY` in Environment Variables
- Use `node server.js` as Start command
- Enable Puppeteer by passing:
```js
args: ['--no-sandbox', '--disable-setuid-sandbox']
```

### Frontend (Expo)
- Use `expo build:android` to generate APK
- Or deploy via Expo Go for instant sharing

---

## 🙌 Credits

Built by a lazy genius who’d rather automate than fill out job apps.