import React from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

export default function PreferencesScreen({ navigation, route }) {
  const [location, setLocation] = React.useState('');
  const [rate, setRate] = React.useState('');
  const [shift, setShift] = React.useState('');

  return (
    <View style={styles.container}>
      <TextInput placeholder="Location" onChangeText={setLocation} style={styles.input} />
      <TextInput placeholder="Min Rate (£/hr)" keyboardType="numeric" onChangeText={setRate} style={styles.input} />
      <TextInput placeholder="Preferred Shift (day/night)" onChangeText={setShift} style={styles.input} />
      <Button title="See Jobs" onPress={() => navigation.navigate('Jobs')} />
    </View>
  );
}
const styles = StyleSheet.create({ container: { padding: 20 }, input: { borderBottomWidth: 1, marginBottom: 20 } });