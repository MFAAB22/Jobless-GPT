import React from 'react';
import { View, Button, TextInput, StyleSheet } from 'react-native';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = React.useState('');

  return (
    <View style={styles.container}>
      <TextInput placeholder="Enter email" onChangeText={setEmail} style={styles.input} />
      <Button title="Continue" onPress={() => navigation.navigate('Upload', { email })} />
    </View>
  );
}
const styles = StyleSheet.create({ container: { padding: 20 }, input: { borderBottomWidth: 1, marginBottom: 20 } });